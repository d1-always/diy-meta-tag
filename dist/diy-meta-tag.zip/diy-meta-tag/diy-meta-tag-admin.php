<?php
/**
 * DIY Meta Tag Admin
 * 
 * Handles the admin interface and functionality for the DIY Meta Tag plugin.
 * Allows users to add, edit and remove meta tags for posts and pages.
 *
 * @package DIY_Meta_Tag
 * @since 1.0.0
 */

add_action('add_meta_boxes', 'diymt_add_meta_box');
function diymt_add_meta_box() {
    add_meta_box(
        'diymt_meta_box',
        __('Meta Tag Manager', 'diy-meta-tag'),
        'diymt_meta_box_callback',
        ['post', 'page'],
        'side'
    );
}

function diymt_meta_box_callback($post) {
    wp_nonce_field('diymt_save_meta_box_data', 'diymt_meta_box_nonce');
    $meta_tags = get_post_meta($post->ID, 'diymt_data', true);
    if (is_serialized($meta_tags)) {
        $meta_tags = unserialize($meta_tags);
    }
    ?>
    <div id="diymt_meta_tags">
        <?php if (!empty($meta_tags)) : ?>
            <?php foreach ($meta_tags as $index => $tag) : ?>
                <div class="diymt_meta_tag">
                    <select name="diymt_meta_tags[<?php echo $index; ?>][type]">
                        <option value="name" <?php selected($tag['type'], 'name'); ?>>Name</option>
                        <option value="property" <?php selected($tag['type'], 'property'); ?>>Property</option>
                    </select>
                    <input type="text" name="diymt_meta_tags[<?php echo $index; ?>][key]" value="<?php echo esc_attr($tag['key']); ?>" placeholder="Key" />
                    <input type="text" name="diymt_meta_tags[<?php echo $index; ?>][value]" value="<?php echo esc_attr($tag['value']); ?>" placeholder="Value" />
                    <button type="button" class="remove-meta-tag">Remove</button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <button type="button" id="add-meta-tag">Add Meta Tag</button>
    <script>
        document.getElementById('add-meta-tag').addEventListener('click', function() {
            var container = document.getElementById('diymt_meta_tags');
            var index = container.children.length;
            var div = document.createElement('div');
            div.className = 'diymt_meta_tag';
            div.innerHTML = `
                <select name="diymt_meta_tags[${index}][type]">
                    <option value="name">Name</option>
                    <option value="property">Property</option>
                </select>
                <input type="text" name="diymt_meta_tags[${index}][key]" placeholder="Key" />
                <input type="text" name="diymt_meta_tags[${index}][value]" placeholder="Value" />
                <button type="button" class="remove-meta-tag">Remove</button>
            `;
            container.appendChild(div);
            div.querySelector('.remove-meta-tag').addEventListener('click', function() {
                div.remove();
            });
        });
        document.querySelectorAll('.remove-meta-tag').forEach(function(button) {
            button.addEventListener('click', function() {
                button.parentElement.remove();
            });
        });
    </script>
    <style>
        .diymt_meta_tag {
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }
        .diymt_meta_tag select,
        .diymt_meta_tag input {
            margin-right: 5px;
        }
        .remove-meta-tag {
            color: red;
            cursor: pointer;
        }
    </style>
    <?php
}

add_action('save_post', 'diymt_save_meta_box_data');
function diymt_save_meta_box_data($post_id) {
    if (!isset($_POST['diymt_meta_box_nonce'])) {
        return;
    }
    if (!wp_verify_nonce($_POST['diymt_meta_box_nonce'], 'diymt_save_meta_box_data')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    if (!isset($_POST['diymt_meta_tags'])) {
        return;
    }
    $meta_tags = array_map(function($tag) {
        return [
            'type' => sanitize_text_field($tag['type']),
            'key' => sanitize_text_field($tag['key']),
            'value' => sanitize_text_field($tag['value']),
        ];
    }, $_POST['diymt_meta_tags']);
    update_post_meta($post_id, 'diymt_data', serialize($meta_tags));
}