<?php
/*
Plugin Name: DIY Meta Tag
Plugin URI: https://example.com
Description: A simple plugin to manage custom meta tags for posts and pages.
Author: sandy, lshfyy
Version: 1.0
Author URI: https://example.com
Text Domain: diy-meta-tag
*/

if (!defined('ABSPATH')) exit; // Prevent direct access to this file

// Define plugin-related constants
define('DIYMT_VERSION', '1.0'); // Define version constant
define('DIYMT_DIR_URL', trailingslashit(plugin_dir_url(__FILE__))); // Define plugin URL path constant
define('DIYMT_DIR', dirname(__FILE__)); // Define plugin directory path constant

class DIY_Meta_Tag { // Define main plugin class
    public static function init() { // Initialization method
        if (is_admin()) { // If in admin interface
            require_once('diy-meta-tag-admin.php'); // Load admin-related file
        }
        add_action('wp_head', 'DIY_Meta_Tag::head', 1); // Add head hook
        do_action('diymt_loaded'); // Trigger plugin loaded action hook
    }

    public static function head() { // Method to handle the head section of the front-end page
        // if (!is_single() && !is_page()) { // Return if not a single post or page
        //     return;
        // }

        static::load('meta-tags'); // Load meta tags module
        $meta_tags = array();
        // Check global tags and filter out ones we'll show for this page
        $meta_tags_data = apply_filters('diymt_head_meta_tags_pre', self::get_post_data()); // Get and filter global meta tag data

        error_log(print_r($meta_tags_data, true));
        foreach( $meta_tags_data as $tag ){ // Iterate over tag data
            error_log('=== DIY Meta Tag Debug ===');
            error_log('Tag data:');
            error_log(print_r($tag, true));
            error_log('=== End Debug 123 ===');
            $meta_tags[] = $tag; // Add valid tags to output array
        }
        error_log(print_r($meta_tags, true)); // Log data
        $meta_tags = apply_filters('diymt_head_meta_tags', $meta_tags); // Apply filter

        // Output the filtered tags that pass validation
        if( !empty($meta_tags) ){ // If there are meta tags to output
            // Add as keys to prevent duplicates
            $meta_tag_strings = array(); // Initialize output string array
            foreach( $meta_tags as $tag ){ // Iterate over all tags
                // Only output valid keys
                if( $tag->is_valid() ){ // If tag is valid
                    $meta_tag_strings[$tag->output()] = 1; // Add to output array
                }
            }
            // Print the HTML to output
            error_log('=== DIY Meta Tag Debug ===');
            error_log('Meta tag strings to output:');
            error_log(print_r($meta_tag_strings, true));
            error_log('=== End Debug ===');
            // Output tags if there are any
            if( !empty($meta_tag_strings) ){ // If there are tags to output
                echo "\r\n\t\t".'<!-- Meta Tag Manager -->'; // Output HTML comment start
                foreach( $meta_tag_strings as $tag_string => $v ){ // Output all tags
                    echo "\r\n\t\t".$tag_string;
                }
                echo "\r\n\t\t".'<!-- / Meta Tag Manager -->'; // Output HTML comment end
                echo "\r\n";
            }
        }
        do_action('diymt_head', $meta_tags); // Trigger head processing completed action hook
    }

    public static function get_post_data($post_id = false) { // Method to get post meta data
        if (empty($post_id)) $post_id = get_the_ID(); // Get current post ID if not specified
        $meta_tag_data = get_post_meta($post_id, 'diymt_data', true); // Get post meta data

        if (is_string($meta_tag_data) && is_serialized($meta_tag_data)) { // If data is a serialized string
            $meta_tag_data = unserialize($meta_tag_data); // Unserialize data
        }

        $meta_tags = []; // Initialize tag array
        if (is_array($meta_tag_data)) { // If meta data is an array
            foreach ($meta_tag_data as $tag_data) { // Iterate over data
                if (!empty($tag_data['key']) && !empty($tag_data['value'])) { // Check if key and value are not empty
                    $meta_tags[] = new DIYMT_Tag($tag_data); // Create non-empty tag object
                }
            }
        }
        // Debug log - print meta tag data
        // error_log('=== DIY Meta Tag Debug ===');
        // error_log('Post ID: ' . $post_id);
        // error_log('Raw meta_tag_data:');
        // error_log(print_r($meta_tag_data, true));
        // error_log('Processed meta_tags:'); 
        error_log(print_r($meta_tags, true));
        error_log('=== End Debug ===');
        return $meta_tags; // Return tag array
    }

    public static function load($module = 'all') { // Method to load modules
        if ($module == 'meta-tags' || $module == 'all') { // If meta-tags module or all
            include_once('diymt-tag.php'); // Include tag class file
        }
    }
}

add_action('plugins_loaded', ['DIY_Meta_Tag', 'init'], 100); // Initialize this plugin when WordPress loads plugins