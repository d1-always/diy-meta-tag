=== DIY Meta Tag ===
Contributors: sandy,lshfyy
Tags: meta tags, SEO, custom meta
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A simple plugin to manage custom meta tags for posts and pages.

== Description ==

DIY Meta Tag is a simple WordPress plugin that allows you to add and manage custom meta tags for your posts and pages. This can be useful for SEO purposes or for adding additional metadata to your content.

== Installation ==

1. Upload the `diy-meta-tag` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to any post or page edit screen to add custom meta tags.

== Usage ==

1. Edit any post or page.
2. In the "Meta Tag Manager" box on the right side, you can add new meta tags by selecting the type (name or property), entering the key, and the value.
3. Click "Add Meta Tag" to add more tags.
4. Click "Remove" to delete a tag.
5. Save or update the post/page to store the meta tags.

== Frequently Asked Questions ==

= How do I add a meta tag? =

Go to the post or page edit screen, find the "Meta Tag Manager" box, and use the interface to add your desired meta tags.

= Can I use this plugin for SEO? =

Yes, you can use this plugin to add SEO-related meta tags to your posts and pages.

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
Initial release of DIY Meta Tag.

== Screenshots ==

1. Meta Tag Manager interface on the post edit screen.

== License ==

This plugin is licensed under the GPLv2 or later.
